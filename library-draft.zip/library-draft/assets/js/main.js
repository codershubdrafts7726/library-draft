document.addEventListener('DOMContentLoaded', function(){
  // Active nav highlight
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav a').forEach(a=>{ if(a.getAttribute('href')===path) a.classList.add('active'); });

  // Accordion for announcements
  document.querySelectorAll('.acc-header').forEach(h=>{
    h.addEventListener('click', ()=>{
      const body = h.parentElement.querySelector('.acc-body');
      const open = body.style.display === 'block';
      document.querySelectorAll('.acc-body').forEach(b=>b.style.display='none');
      if(!open) body.style.display = 'block';
    });
  });

  // Drawer toggle (mobile)
  const hamburger = document.querySelector('.hamburger');
  const drawer = document.querySelector('.drawer');
  const backdrop = document.querySelector('.drawer-backdrop');
  if(hamburger && drawer && backdrop){
    hamburger.addEventListener('click', ()=>{ drawer.classList.add('open'); backdrop.classList.add('open'); drawer.setAttribute('aria-hidden','false'); backdrop.setAttribute('aria-hidden','false'); });
    backdrop.addEventListener('click', ()=>{ drawer.classList.remove('open'); backdrop.classList.remove('open'); drawer.setAttribute('aria-hidden','true'); backdrop.setAttribute('aria-hidden','true'); });
    document.addEventListener('keydown', (e)=>{ if(e.key==='Escape'){ drawer.classList.remove('open'); backdrop.classList.remove('open'); }});
  }

  // Demo search button (homepage)
  const searchBtn = document.getElementById('searchBtn');
  const searchBox = document.getElementById('searchBox');
  if(searchBtn && searchBox){
    searchBtn.addEventListener('click', ()=>{
      alert('Search is demo-only. Replace with OPAC integration.');
    });
  }

  // Books search on books page
  const booksSearch = document.getElementById('booksSearch');
  if(booksSearch){
    booksSearch.addEventListener('input', function(e){
      const q = e.target.value.toLowerCase();
      document.querySelectorAll('#booksTable tbody tr').forEach(tr=>{
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  }
});
